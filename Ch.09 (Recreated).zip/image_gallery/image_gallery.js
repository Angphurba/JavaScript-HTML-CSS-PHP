$(document).ready(function() {
$("#image_list a").each(function() {
var imageURL = $(this).attr("href");
var caption = $(this).attr("title");
var galleryImage = new Image();
galleryImage.src = imageURL;
$(this).click(function(evt) {
$("#image").attr("src", imageURL);  
$("#image").fadeToggle(3000);   
evt.preventDefault();
});
});
  
});